const express = require('express');
const session = require('express-session');
const path = require('path');
require('dotenv').config();

const app = express();

// 0. Hàm format thời gian chuẩn (dd/mm/yyyy hh:mm:ss) dùng chung cho mọi file EJS
app.locals.formatDateTime = function(dateString) {
    if (!dateString) return '';
    const d = new Date(dateString);
    const pad = (n) => n < 10 ? '0' + n : n; // Thêm số 0 đằng trước nếu nhỏ hơn 10
    
    const day = pad(d.getDate());
    const month = pad(d.getMonth() + 1);
    const year = d.getFullYear();
    const hours = pad(d.getHours());
    const minutes = pad(d.getMinutes());
    const seconds = pad(d.getSeconds());
    
    return `${day}/${month}/${year} ${hours}:${minutes}:${seconds}`;
};

// 1. Cấu hình Middleware
app.use(express.urlencoded({ extended: true })); // Xử lý dữ liệu từ Form (Tiếng Việt mượt mà) [cite: 17]
app.use(express.json()); // Xử lý dữ liệu JSON
app.use(express.static(path.join(__dirname, 'public'))); // Phục vụ file tĩnh (CSS, JS) [cite: 86]
app.set('view engine', 'ejs'); // Sử dụng EJS để render phía server [cite: 92]

// 2. Cấu hình Session (Tối ưu cho RAM 1GB) [cite: 107]
app.use(session({
    secret: process.env.SESSION_SECRET || 'fta_secret_key',
    resave: false,
    saveUninitialized: true,
    cookie: { 
        maxAge: 1000 * 60 * 60 * 24, // Session tồn tại 24h
        secure: false 
    }
}));

// 3. Import Routes [cite: 88]
app.use('/auth', require('./routes/auth'));
app.use('/staff', require('./routes/staff'));
app.use('/admin', require('./routes/admin'));

// 4. Điều hướng trang chủ dựa trên Role [cite: 31, 39, 76]
app.get('/', (req, res) => {
    if (!req.session.userId) return res.redirect('/auth/login');
    // Nếu là Admin thì vào dashboard, Staff thì vào thẳng Menu chính
    res.redirect(req.session.role === 'Admin' ? '/admin/dashboard' : '/staff');
});

// 5. Middleware xử lý lỗi 404 (PHẢI NẰM CUỐI CÙNG) 
// Nếu không có route nào ở trên khớp, lệnh này sẽ chạy
app.use((req, res) => {
    res.status(404).send('Không tìm thấy trang này. Vui lòng kiểm tra lại đường dẫn!');
});

// 6. Kích hoạt Server
const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
    console.log(`🚀 Hệ thống CRM chạy tại: http://localhost:${PORT}`);
});