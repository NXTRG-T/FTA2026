const express = require('express');
const router = express.Router();
const db = require('../config/db'); // Kết nối DB đã tạo [cite: 85]

// Middleware kiểm tra quyền Admin
const isAdmin = (req, res, next) => {
    if (req.session.role === 'Admin') return next();
    res.redirect('/auth/login');
};

// 1. Trang Dashboard (Báo cáo KPI tổng hợp)
router.get('/dashboard', isAdmin, async (req, res) => {
    try {
        // Sử dụng COUNT() để tính toán trực tiếp trên Database giúp tiết kiệm RAM
        const [[{ total_customers }]] = await db.execute('SELECT COUNT(*) as total_customers FROM Customers WHERE is_deleted = 0');
        const [[{ total_staff }]] = await db.execute('SELECT COUNT(*) as total_staff FROM Users WHERE role = "Staff" AND is_deleted = 0');

        // Lấy sự kiện sắp diễn ra (5 sự kiện gần nhất tính từ hiện tại)
        const [upcoming_events] = await db.execute(
            'SELECT id, event_name, start_time, location FROM Events WHERE start_time >= NOW() ORDER BY start_time ASC LIMIT 5'
        );

        // Lấy khách hàng có sinh nhật trong 30 ngày tới
        const [upcoming_birthdays] = await db.execute(`
            SELECT id, full_name, phone_1, birthday 
            FROM Customers 
            WHERE is_deleted = 0 AND birthday IS NOT NULL 
            AND (
                DATE_FORMAT(birthday, '%m-%d') BETWEEN DATE_FORMAT(NOW(), '%m-%d') AND DATE_FORMAT(DATE_ADD(NOW(), INTERVAL 30 DAY), '%m-%d')
                OR 
                (MONTH(NOW()) = 12 AND DATE_FORMAT(birthday, '%m-%d') <= DATE_FORMAT(DATE_ADD(NOW(), INTERVAL 30 DAY), '%m-%d'))
            )
            ORDER BY MONTH(birthday) ASC, DAY(birthday) ASC 
            LIMIT 10
        `);

        res.render('admin/dashboard', { 
            username: req.session.username,
            total_customers,
            total_staff,
            upcoming_events,
            upcoming_birthdays
        });
    } catch (err) {
        console.error(err);
        res.status(500).send('Lỗi tải dữ liệu Dashboard');
    }
});

// 2. Trang Quản lý Tag (Lấy danh sách Tag)
router.get('/tags', isAdmin, async (req, res) => {
    try {
        // Chỉ lấy các cột cần thiết để tiết kiệm RAM [cite: 98, 111]
        const [tags] = await db.execute('SELECT id, tag_name, color_code FROM Tags');
        res.render('admin/tags', { tags });
    } catch (err) {
        res.status(500).send('Lỗi lấy dữ liệu Tag');
    }
});

// 3. Xử lý thêm Tag mới
router.post('/tags/add', isAdmin, async (req, res) => {
    const { tag_name, color_code } = req.body;
    try {
        await db.execute('INSERT INTO Tags (tag_name, color_code) VALUES (?, ?)', [tag_name, color_code]);
        res.redirect('/admin/tags');
    } catch (err) {
        res.status(500).send('Lỗi khi thêm Tag');
    }
});

// Hàm hỗ trợ ghi Log (Đã thêm targetUserId)
const logAction = async (userId, targetUserId, actionType, content) => {
    try {
        await db.execute(
            'INSERT INTO Action_Logs (user_id, target_user_id, action_type, content) VALUES (?, ?, ?, ?)',
            [userId, targetUserId, actionType, content]
        );
    } catch (error) {
        console.error('Lỗi ghi log:', error);
    }
};

// Hàm loại bỏ ký tự lạ, chỉ giữ lại số
const cleanToNumbers = (val) => val ? val.replace(/\D/g, '') : null;

// 4. Trang Quản lý Nhân sự (Xem danh sách Staff & Lịch sử)
router.get('/staff-management', isAdmin, async (req, res) => {
    try {
        // CẬP NHẬT: Lấy thêm các trường mới để hiển thị ra giao diện
        const [staffs] = await db.execute(
            `SELECT id, username, full_name, role, is_locked, lock_message, 
                    birthday, cccd, phone_1, phone_2, business_code, 
                    email, address, work_area, start_date, end_date 
             FROM Users 
             WHERE role = "Staff" AND is_deleted = 0`
        );
        
        // Lấy lịch sử thao tác của các nhân viên (Giữ nguyên)
        const [logs] = await db.execute(`
            SELECT al.target_user_id, al.content, al.created_at, u.username as actor_name
            FROM Action_Logs al
            LEFT JOIN Users u ON al.user_id = u.id
            WHERE al.target_user_id IS NOT NULL
            ORDER BY al.created_at DESC
        `);

        staffs.forEach(staff => {
            staff.history = logs.filter(log => log.target_user_id === staff.id);
        });

        res.render('admin/staff', { staffs });
    } catch (err) {
        console.error(err);
        res.status(500).send('Lỗi lấy danh sách nhân sự');
    }
});

// 5a. Xử lý THÊM nhân viên mới
router.post('/staff/add', isAdmin, async (req, res) => {
    let { 
        username, password, full_name, birthday, cccd, 
        phone_1, phone_2, business_code, email, address, 
        work_area, start_date, end_date 
    } = req.body;

    // 1. Tự động IN HOA họ tên nhân viên
    const formattedName = full_name.toUpperCase().trim();

    // 2. Chuẩn hóa số (Loại bỏ ký tự lạ, giữ số 0 ở đầu)
    const safeCCCD = cleanToNumbers(cccd);
    const safePhone1 = cleanToNumbers(phone_1);
    const safePhone2 = cleanToNumbers(phone_2);
    const safeBizCode = cleanToNumbers(business_code);

    try {
        const [result] = await db.execute(
            `INSERT INTO Users (
                username, password, full_name, role, birthday, cccd, 
                phone_1, phone_2, business_code, email, address, 
                work_area, start_date, end_date
            ) VALUES (?, ?, ?, 'Staff', ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
            [
                username, password, formattedName, birthday, safeCCCD, 
                safePhone1, safePhone2, safeBizCode, email || null, address || null, 
                work_area || null, start_date || null, end_date || null
            ]
        );
        
        await logAction(req.session.userId, result.insertId, 'ADD_STAFF', `Tạo nhân viên: ${formattedName}`);
        res.redirect('/admin/staff-management');
    } catch (err) {
        console.error(err);
        res.status(500).send("Lỗi: Số CCCD hoặc Tên đăng nhập đã tồn tại!");
    }
});

// 5b. Xử lý CẬP NHẬT thông tin nhân viên
router.post('/staff/edit/:id', isAdmin, async (req, res) => {
    const staffId = req.params.id;
    let { 
        full_name, password, birthday, cccd, phone_1, phone_2, 
        business_code, email, address, start_date, end_date, work_area 
    } = req.body;

    // Chuẩn hóa dữ liệu tương tự lúc thêm mới
    const formattedName = full_name.toUpperCase().trim();
    const safeCCCD = cleanToNumbers(cccd);
    const safePhone1 = cleanToNumbers(phone_1);
    const safePhone2 = cleanToNumbers(phone_2);
    const safeBizCode = cleanToNumbers(business_code);

    try {
        let sql = `UPDATE Users SET full_name=?, birthday=?, cccd=?, phone_1=?, phone_2=?, business_code=?, email=?, address=?, start_date=?, end_date=?, work_area=?`;
        let params = [formattedName, birthday, safeCCCD, safePhone1, safePhone2, safeBizCode, email || null, address || null, start_date || null, end_date || null, work_area || null];

        // Nếu Admin có nhập mật khẩu mới thì mới đổi
        if (password && password.trim() !== '') {
            sql += `, password=?`;
            params.push(password);
        }

        sql += ` WHERE id=?`;
        params.push(staffId);

        await db.execute(sql, params);
        await logAction(req.session.userId, staffId, 'EDIT_STAFF', `Cập nhật thông tin nhân viên: ${formattedName}`);
        
        res.redirect('/admin/staff-management');
    } catch (err) {
        console.error(err);
        res.status(500).send('Lỗi cập nhật thông tin nhân viên (Có thể trùng CCCD).');
    }
});

// Xử lý ĐẶT LẠI MẬT KHẨU nhân viên (Dành cho Admin)
router.post('/staff/change-password/:id', isAdmin, async (req, res) => {
    const staffId = req.params.id;
    const { new_password } = req.body;
    try {
        await db.execute(
            'UPDATE Users SET password = ? WHERE id = ?',
            [new_password, staffId]
        );
        await logAction(req.session.userId, staffId, 'CHANGE_PASSWORD', `Admin đặt lại mật khẩu cho nhân viên`);
        res.redirect('/admin/staff-management');
    } catch (err) {
        console.error(err);
        res.status(500).send('Lỗi cập nhật mật khẩu');
    }
});

// 5c. Xử lý XÓA nhân viên (Xóa mềm - Lưu thời gian xóa)
router.post('/staff/delete/:id', isAdmin, async (req, res) => {
    const staffId = req.params.id;
    try {
        // Cập nhật is_deleted = 1 và lưu thời gian deleted_at = NOW()
        await db.execute('UPDATE Users SET is_deleted = 1, is_locked = 1, lock_message = "Tài khoản đã bị xóa", deleted_at = NOW() WHERE id = ?', [staffId]);
        await logAction(req.session.userId, staffId, 'DELETE_STAFF', `Chuyển nhân viên vào danh sách Đã xóa`);
        res.redirect('/admin/staff-management');
    } catch (err) {
        res.status(500).send('Lỗi khi xóa nhân viên.');
    }
});

// 5d. Xử lý KHÓA/MỞ KHÓA nhân viên
router.post('/staff/toggle-lock/:id', isAdmin, async (req, res) => {
    const staffId = req.params.id;
    const { is_locked, lock_message } = req.body; 
    try {
        await db.execute(
            'UPDATE Users SET is_locked = ?, lock_message = ? WHERE id = ?',
            [is_locked, is_locked === '1' ? lock_message : null, staffId]
        );
        
        // Định dạng câu Log đúng chuẩn yêu cầu
        const logMsg = is_locked === '1' ? `khóa: Lý do ${lock_message}` : `mở khóa tài khoản`;
        await logAction(req.session.userId, staffId, 'LOCK_STAFF', logMsg);
        
        res.redirect('/admin/staff-management');
    } catch (err) {
        res.status(500).send('Lỗi cập nhật trạng thái');
    }
});

// 5e. Xem chi tiết nhân viên và lịch sử thao tác
router.get('/staff/detail/:id', isAdmin, async (req, res) => {
    try {
        const staffId = req.params.id;
        
        // 1. Lấy thông tin nhân viên
        const [staff] = await db.execute(`
            SELECT * FROM Users WHERE id = ? AND role = 'Staff'
        `, [staffId]);
        
        if (staff.length === 0) return res.status(404).send('Không tìm thấy nhân viên');

        // 2. Lấy lịch sử thao tác (Logs do nhân viên này thực hiện hoặc tác động lên nhân viên này)
        const [logs] = await db.execute(`
            SELECT al.*, u.full_name as actor_name 
            FROM Action_Logs al
            LEFT JOIN Users u ON al.user_id = u.id
            WHERE al.user_id = ? OR al.target_user_id = ?
            ORDER BY al.created_at DESC
        `, [staffId, staffId]);

        res.render('admin/staff-detail', { staff: staff[0], logs });
    } catch (err) {
        console.error(err);
        res.status(500).send('Lỗi tải chi tiết nhân viên');
    }
});

// 8. Trang Báo cáo & Thống kê chi tiết (Nâng cấp bộ lọc đa chọn)
router.get('/reports', isAdmin, async (req, res) => {
    // Nhận mảng ID từ query (Express tự động chuyển thành mảng nếu chọn nhiều)
    let staff_ids = req.query.staff_ids || [];
    if (!Array.isArray(staff_ids)) staff_ids = [staff_ids];

    let tag_ids = req.query.tag_ids || [];
    if (!Array.isArray(tag_ids)) tag_ids = [tag_ids];

    const { start_date, end_date } = req.query;
    const keyword = req.query.keyword || ''; // Lấy từ khóa tìm kiếm
    
    // Lấy danh sách cột cần hiển thị, mặc định hiện tất cả nếu chưa chọn 
    const show_cols = req.query.show_cols || ['created_at', 'full_name', 'phone_1', 'staff_name', 'tag_names'];

    try {
        const [staffList] = await db.execute('SELECT id, full_name FROM Users WHERE role = "Staff" AND is_deleted = 0');
        const [tagList] = await db.execute('SELECT id, tag_name FROM Tags');

        let sql = `
            SELECT c.id, c.full_name, c.phone_1, c.created_at, u.full_name as staff_name,
            GROUP_CONCAT(t.tag_name SEPARATOR ',') as tag_names,
            GROUP_CONCAT(t.color_code SEPARATOR ',') as tag_colors
            FROM Customers c
            LEFT JOIN Users u ON c.staff_id = u.id
            LEFT JOIN Customer_Tags ct ON c.id = ct.customer_id
            LEFT JOIN Tags t ON ct.tag_id = t.id
            WHERE c.is_deleted = 0
        `;
        const params = [];

        // Lọc theo danh sách nhiều nhân viên 
        if (staff_ids.length > 0) {
            sql += ` AND c.staff_id IN (${staff_ids.map(() => '?').join(',')})`;
            staff_ids.forEach(id => params.push(id));
        }

        // Lọc theo danh sách nhiều Tag [cite: 5]
        if (tag_ids.length > 0) {
            sql += ` AND EXISTS (SELECT 1 FROM Customer_Tags ct2 WHERE ct2.customer_id = c.id AND ct2.tag_id IN (${tag_ids.map(() => '?').join(',')}))`;
            tag_ids.forEach(id => params.push(id));
        }

        if (start_date) {
            sql += ` AND DATE(c.created_at) >= ?`;
            params.push(start_date);
        }
        if (end_date) {
            sql += ` AND DATE(c.created_at) <= ?`;
            params.push(end_date);
        }

        // --- BỘ LỌC TÌM KIẾM MỚI (TÊN HOẶC SĐT) ---
        if (keyword.trim() !== '') {
            sql += ` AND (c.full_name LIKE ? OR c.phone_1 LIKE ?)`;
            params.push(`%${keyword.trim()}%`, `%${keyword.trim()}%`);
        }

        sql += ` GROUP BY c.id ORDER BY c.created_at DESC`;

        const [customers] = await db.execute(sql, params);

        res.render('admin/reports', {
            customers,
            staffList,
            tagList,
            show_cols,
            query: { ...req.query, staff_ids, tag_ids, keyword } // Trả keyword về UI
        });
    } catch (err) {
        console.error(err);
        res.status(500).send('Lỗi hệ thống báo cáo');
    }
});

// Xem chi tiết toàn diện khách hàng (Dành cho Admin)
router.get('/customers/detail/:id', isAdmin, async (req, res) => {
    try {
        const customerId = req.params.id;
        
        // 1. Lấy thông tin cơ bản & nhân viên chăm sóc
        const [customer] = await db.execute(`
            SELECT c.*, u.full_name as staff_name 
            FROM Customers c 
            LEFT JOIN Users u ON c.staff_id = u.id 
            WHERE c.id = ?`, [customerId]
        );
        if (customer.length === 0) return res.status(404).send('Không tìm thấy khách hàng');

        // 2. Lấy danh sách Tags
        const [tags] = await db.execute(`
            SELECT t.tag_name, t.color_code 
            FROM Customer_Tags ct 
            JOIN Tags t ON ct.tag_id = t.id 
            WHERE ct.customer_id = ?`, [customerId]
        );

        // 3. Lấy kết quả khảo sát (Parse JSON)
        const [surveys] = await db.execute('SELECT question_data, completed_at FROM Surveys WHERE customer_id = ? ORDER BY completed_at DESC', [customerId]);
        const surveyData = surveys.length > 0 ? surveys[0] : null;

        // 4. Lấy lịch sử tham gia sự kiện
        const [events] = await db.execute(`
            SELECT e.event_name, e.start_time, ep.status, ep.notes 
            FROM Event_Participants ep 
            JOIN Events e ON ep.event_id = e.id 
            WHERE ep.customer_id = ? 
            ORDER BY e.start_time DESC`, [customerId]
        );

        res.render('admin/customer-detail', { 
            cust: customer[0], 
            tags, 
            survey: surveyData, 
            events 
        });
    } catch (err) {
        console.error(err);
        res.status(500).send('Lỗi tải chi tiết khách hàng');
    }
});

// 9. Tab "Đã xóa" (Cập nhật truy vấn lấy thêm thời gian deleted_at)
router.get('/trash', isAdmin, async (req, res) => {
    try {
        const [deletedStaffs] = await db.execute(
            'SELECT id, username, full_name, deleted_at FROM Users WHERE role = "Staff" AND is_deleted = 1 ORDER BY deleted_at DESC'
        );
        const [deletedCustomers] = await db.execute(`
            SELECT c.id, c.full_name, c.phone_1, c.deleted_at, u.full_name as staff_name 
            FROM Customers c 
            LEFT JOIN Users u ON c.staff_id = u.id 
            WHERE c.is_deleted = 1
            ORDER BY c.deleted_at DESC
        `);
        res.render('admin/trash', { deletedStaffs, deletedCustomers });
    } catch (err) {
        res.status(500).send('Lỗi tải dữ liệu thùng rác');
    }
});

// ==========================================
// XỬ LÝ KHÔI PHỤC TỪ THÙNG RÁC
// ==========================================

// 10. Khôi phục Nhân viên
router.post('/staff/restore/:id', isAdmin, async (req, res) => {
    try {
        await db.execute(
            'UPDATE Users SET is_deleted = 0, is_locked = 0, lock_message = NULL, deleted_at = NULL WHERE id = ?', 
            [req.params.id]
        );
        await logAction(req.session.userId, req.params.id, 'RESTORE_STAFF', `Khôi phục tài khoản nhân viên từ Thùng rác`);
        res.redirect('/admin/trash');
    } catch (err) {
        console.error(err);
        res.status(500).send('Lỗi khôi phục nhân viên');
    }
});

// 11. Khôi phục Khách hàng
router.post('/customers/restore/:id', isAdmin, async (req, res) => {
    try {
        await db.execute(
            'UPDATE Customers SET is_deleted = 0, deleted_at = NULL WHERE id = ?', 
            [req.params.id]
        );
        await logAction(req.session.userId, null, 'RESTORE_CUSTOMER', `Admin khôi phục khách hàng ID: ${req.params.id}`);
        res.redirect('/admin/trash');
    } catch (err) {
        console.error(err);
        res.status(500).send('Lỗi khôi phục khách hàng');
    }
});

// ==========================================
// XỬ LÝ SỬA THÔNG TIN KHÁCH HÀNG (ADMIN)
// ==========================================

// 12. HIỂN THỊ GIAO DIỆN FORM SỬA KHÁCH HÀNG (ĐÂY LÀ ROUTE BẠN BỊ THIẾU)
router.get('/customers/edit/:id', isAdmin, async (req, res) => {
    try {
        const [customer] = await db.execute('SELECT * FROM Customers WHERE id = ?', [req.params.id]);
        if (customer.length === 0) return res.status(404).send('Không tìm thấy khách hàng');
        
        res.render('admin/edit-customer', { cust: customer[0] });
    } catch (err) {
        console.error(err);
        res.status(500).send('Lỗi tải thông tin khách hàng');
    }
});

// 13. Xử lý LƯU thông tin khách hàng khi Admin bấm Cập nhật
router.post('/customers/edit/:id', isAdmin, async (req, res) => {
    const { full_name, phone_1, phone_2, birthday, cccd, address_1, address_2, email } = req.body;
    try {
        await db.execute(
            `UPDATE Customers SET 
            full_name = ?, phone_1 = ?, phone_2 = ?, birthday = ?, 
            cccd = ?, address_1 = ?, address_2 = ?, email = ? 
            WHERE id = ?`,
            [full_name, phone_1, phone_2 || null, birthday || null, cccd || null, address_1 || null, address_2 || null, email || null, req.params.id]
        );
        await logAction(req.session.userId, null, 'EDIT_CUSTOMER', `Admin sửa thông tin khách hàng: ${full_name}`);
        res.redirect('/admin/reports'); // Quay lại trang báo cáo
    } catch (err) {
        res.status(500).send('Lỗi cập nhật khách hàng');
    }
});

// ==========================================
// QUẢN LÝ SỰ KIỆN (EVENTS)
// ==========================================

// 1. Hiển thị danh sách Sự kiện
router.get('/events', isAdmin, async (req, res) => {
    try {
        // Lấy danh sách sự kiện (Đã đổi thành start_time, end_time, location)
        const [events] = await db.execute('SELECT * FROM Events ORDER BY start_time DESC');
        
        // Lấy danh sách nhân viên đang hoạt động để Admin chọn người phụ trách
        const [staffList] = await db.execute('SELECT id, full_name FROM Users WHERE role = "Staff" AND is_deleted = 0');
        
        // Lấy danh sách nhân viên phụ trách cho từng sự kiện
        for (let ev of events) {
            const [managers] = await db.execute(`
                SELECT u.id, u.full_name 
                FROM Event_Managers em
                JOIN Users u ON em.user_id = u.id
                WHERE em.event_id = ?
            `, [ev.id]);
            ev.managers = managers; // Gắn mảng người phụ trách vào sự kiện
        }

        res.render('admin/events', { events, staffList });
    } catch (err) {
        console.error(err);
        res.status(500).send('Lỗi tải danh sách sự kiện');
    }
});

// 2. Thêm mới Sự kiện (Đã bổ sung description và drive_link)
router.post('/events/add', isAdmin, async (req, res) => {
    const { event_name, location, start_time, end_time, description, drive_link, manager_ids } = req.body;
    try {
        const [result] = await db.execute(
            'INSERT INTO Events (event_name, location, start_time, end_time, description, drive_link) VALUES (?, ?, ?, ?, ?, ?)',
            [event_name, location, start_time, end_time, description || null, drive_link || null]
        );
        const newEventId = result.insertId;

        if (manager_ids) {
            const ids = Array.isArray(manager_ids) ? manager_ids : [manager_ids];
            for (let uid of ids) {
                await db.execute('INSERT INTO Event_Managers (event_id, user_id) VALUES (?, ?)', [newEventId, uid]);
            }
        }

        await logAction(req.session.userId, null, 'ADD_EVENT', `Tạo sự kiện: ${event_name}`);
        res.redirect('/admin/events');
    } catch (err) {
        console.error(err);
        res.status(500).send('Lỗi khi tạo sự kiện');
    }
});

// 2b. XỬ LÝ SỬA SỰ KIỆN CHƯA DIỄN RA (Tính năng mới)
router.post('/events/edit/:id', isAdmin, async (req, res) => {
    const eventId = req.params.id;
    const { event_name, location, start_time, end_time, description, drive_link, manager_ids } = req.body;
    
    try {
        // Kiểm tra xem sự kiện đã diễn ra chưa
        const [eventCheck] = await db.execute('SELECT start_time FROM Events WHERE id = ?', [eventId]);
        if (eventCheck.length === 0) return res.status(404).send('Không tìm thấy sự kiện');
        
        if (new Date(eventCheck[0].start_time) <= new Date()) {
            return res.status(400).send('Sự kiện đã hoặc đang diễn ra, không thể sửa đổi!');
        }

        // Cập nhật thông tin cơ bản
        await db.execute(
            'UPDATE Events SET event_name=?, location=?, start_time=?, end_time=?, description=?, drive_link=? WHERE id=?',
            [event_name, location, start_time, end_time, description || null, drive_link || null, eventId]
        );

        // Cập nhật người phụ trách (Xóa cũ, Thêm mới)
        await db.execute('DELETE FROM Event_Managers WHERE event_id = ?', [eventId]);
        if (manager_ids) {
            const ids = Array.isArray(manager_ids) ? manager_ids : [manager_ids];
            for (let uid of ids) {
                await db.execute('INSERT INTO Event_Managers (event_id, user_id) VALUES (?, ?)', [eventId, uid]);
            }
        }

        await logAction(req.session.userId, null, 'EDIT_EVENT', `Sửa thông tin sự kiện ID: ${eventId}`);
        res.redirect('/admin/events');
    } catch (err) {
        console.error(err);
        res.status(500).send('Lỗi khi cập nhật sự kiện');
    }
});

// 2c. BÁO CÁO THỐNG KÊ SỰ KIỆN
router.get('/events/stats/:id', isAdmin, async (req, res) => {
    const eventId = req.params.id;
    try {
        const [event] = await db.execute('SELECT event_name FROM Events WHERE id = ?', [eventId]);
        if (event.length === 0) return res.status(404).send('Không tìm thấy sự kiện');

        // Tổng số khách, Tổng số nhân viên
        const [summary] = await db.execute(`
            SELECT 
                COUNT(DISTINCT ep.customer_id) as total_customers,
                COUNT(DISTINCT c.staff_id) as total_staffs
            FROM Event_Participants ep
            JOIN Customers c ON ep.customer_id = c.id
            WHERE ep.event_id = ?
        `, [eventId]);

        // Chi tiết số khách theo từng nhân viên
        const [staff_stats] = await db.execute(`
            SELECT u.full_name as staff_name, COUNT(ep.customer_id) as customer_count
            FROM Event_Participants ep
            JOIN Customers c ON ep.customer_id = c.id
            JOIN Users u ON c.staff_id = u.id
            WHERE ep.event_id = ?
            GROUP BY u.id
            ORDER BY customer_count DESC
        `, [eventId]);

        res.render('admin/event-stats', { event: event[0], summary: summary[0], staff_stats });
    } catch (err) {
        console.error(err);
        res.status(500).send('Lỗi tải báo cáo sự kiện');
    }
});

// 3. Xóa Sự kiện
router.post('/events/delete/:id', isAdmin, async (req, res) => {
    const eventId = req.params.id;
    try {
        // Do đã cấu hình ON DELETE CASCADE trong SQL, khi xóa Event thì dữ liệu trong Event_Managers tự động bị xóa theo
        await db.execute('DELETE FROM Events WHERE id = ?', [eventId]);
        await logAction(req.session.userId, null, 'DELETE_EVENT', `Đã xóa sự kiện ID: ${eventId}`);
        res.redirect('/admin/events');
    } catch (err) {
        console.error(err);
        res.status(500).send('Lỗi khi xóa sự kiện');
    }
});
// ==========================================
// QUẢN LÝ TÀI LIỆU NỘI BỘ (DOCUMENTS)
// ==========================================

// 1. Xem danh sách tài liệu
router.get('/documents', isAdmin, async (req, res) => {
    try {
        const [documents] = await db.execute('SELECT * FROM Documents ORDER BY created_at DESC');
        res.render('admin/documents', { documents });
    } catch (err) {
        console.error(err);
        res.status(500).send('Lỗi tải danh sách tài liệu');
    }
});

// 2. Thêm tài liệu mới
router.post('/documents/add', isAdmin, async (req, res) => {
    const { title, description, file_link } = req.body;
    try {
        await db.execute(
            'INSERT INTO Documents (title, description, file_link) VALUES (?, ?, ?)',
            [title, description || null, file_link]
        );
        await logAction(req.session.userId, null, 'ADD_DOCUMENT', `Thêm tài liệu mới: ${title}`);
        res.redirect('/admin/documents');
    } catch (err) {
        console.error(err);
        res.status(500).send('Lỗi thêm tài liệu');
    }
});

// 3. Sửa thông tin tài liệu
router.post('/documents/edit/:id', isAdmin, async (req, res) => {
    const { title, description, file_link } = req.body;
    try {
        await db.execute(
            'UPDATE Documents SET title = ?, description = ?, file_link = ? WHERE id = ?',
            [title, description || null, file_link, req.params.id]
        );
        await logAction(req.session.userId, null, 'EDIT_DOCUMENT', `Sửa tài liệu ID: ${req.params.id}`);
        res.redirect('/admin/documents');
    } catch (err) {
        console.error(err);
        res.status(500).send('Lỗi sửa tài liệu');
    }
});

// 4. Xóa tài liệu
router.post('/documents/delete/:id', isAdmin, async (req, res) => {
    try {
        await db.execute('DELETE FROM Documents WHERE id = ?', [req.params.id]);
        await logAction(req.session.userId, null, 'DELETE_DOCUMENT', `Xóa tài liệu ID: ${req.params.id}`);
        res.redirect('/admin/documents');
    } catch (err) {
        console.error(err);
        res.status(500).send('Lỗi xóa tài liệu');
    }
});
// ==========================================
// QUẢN LÝ THÔNG BÁO (NOTIFICATIONS)
// ==========================================

// 1. Xem danh sách thông báo
router.get('/notifications', isAdmin, async (req, res) => {
    try {
        const [notifications] = await db.execute(`
            SELECT n.*, u.full_name as creator_name
            FROM Notifications n
            LEFT JOIN Users u ON n.created_by = u.id
            ORDER BY n.created_at DESC
        `);
        res.render('admin/notifications', { notifications, now: new Date() });
    } catch (err) {
        console.error(err);
        res.status(500).send('Lỗi tải danh sách thông báo');
    }
});

// 1b. Xem danh sách nhân viên đã đọc/chưa đọc thông báo (Kèm dữ liệu xuất Báo cáo)
router.get('/notifications/:id/reads', isAdmin, async (req, res) => {
    const notiId = req.params.id;
    try {
        const [noti] = await db.execute('SELECT id, title FROM Notifications WHERE id = ?', [notiId]);
        if (noti.length === 0) return res.status(404).send('Không tìm thấy thông báo');

        // Lấy danh sách ĐÃ ĐỌC kèm thông tin nhân sự chi tiết
        const [readers] = await db.execute(`
            SELECT u.full_name, u.username, u.phone_1, u.work_area, u.business_code, 'Đã đọc' as status
            FROM Notification_Reads nr
            JOIN Users u ON nr.user_id = u.id
            WHERE nr.notification_id = ?
            ORDER BY u.full_name ASC
        `, [notiId]);

        // Lấy danh sách CHƯA ĐỌC kèm thông tin nhân sự chi tiết
        const [unreaders] = await db.execute(`
            SELECT full_name, username, phone_1, work_area, business_code, 'Chưa đọc' as status
            FROM Users 
            WHERE role = 'Staff' AND is_deleted = 0
            AND id NOT IN (SELECT user_id FROM Notification_Reads WHERE notification_id = ?)
            ORDER BY full_name ASC
        `, [notiId]);

        res.render('admin/notification-reads', { 
            noti: noti[0], 
            readers, 
            unreaders,
            all_staff: [...readers, ...unreaders] // Gộp chung để xuất báo cáo
        });
    } catch (err) {
        console.error(err);
        res.status(500).send('Lỗi hệ thống khi tải lượt đọc');
    }
});

// 2. Thêm thông báo mới
router.post('/notifications/add', isAdmin, async (req, res) => {
    const { title, content, drive_link, start_time, end_time } = req.body;
    try {
        await db.execute(
            'INSERT INTO Notifications (title, content, drive_link, start_time, end_time, created_by) VALUES (?, ?, ?, ?, ?, ?)',
            [title, content, drive_link || null, start_time, end_time, req.session.userId]
        );
        await logAction(req.session.userId, null, 'ADD_NOTIFICATION', `Tạo thông báo: ${title}`);
        res.redirect('/admin/notifications');
    } catch (err) {
        console.error(err);
        res.status(500).send('Lỗi thêm thông báo');
    }
});

// 3. Sửa thông báo (Kèm ghi log lịch sử theo yêu cầu)
router.post('/notifications/edit/:id', isAdmin, async (req, res) => {
    const { title, content, drive_link, start_time, end_time } = req.body;
    try {
        await db.execute(
            'UPDATE Notifications SET title = ?, content = ?, drive_link = ?, start_time = ?, end_time = ? WHERE id = ?',
            [title, content, drive_link || null, start_time, end_time, req.params.id]
        );
        // Lưu lịch sử sửa đổi (Chỉ Admin thấy trong tab Nhân sự/Lịch sử thao tác)
        await logAction(req.session.userId, null, 'EDIT_NOTIFICATION', `Cập nhật thông báo ID ${req.params.id}: ${title}`);
        res.redirect('/admin/notifications');
    } catch (err) {
        console.error(err);
        res.status(500).send('Lỗi sửa thông báo');
    }
});

// 4. Xóa thông báo
router.post('/notifications/delete/:id', isAdmin, async (req, res) => {
    try {
        // Xóa thông báo (Các lượt đọc trong Notification_Reads cũng nên được tự động dọn dẹp nếu DB thiết lập khóa ngoại ON DELETE CASCADE)
        await db.execute('DELETE FROM Notifications WHERE id = ?', [req.params.id]);
        await logAction(req.session.userId, null, 'DELETE_NOTIFICATION', `Xóa thông báo ID: ${req.params.id}`);
        res.redirect('/admin/notifications');
    } catch (err) {
        console.error(err);
        res.status(500).send('Lỗi xóa thông báo');
    }
});

// ==========================================
// QUẢN LÝ BIỂU MẪU KHẢO SÁT (SURVEY FORMS)
// ==========================================

// 1. Danh sách biểu mẫu
router.get('/forms', isAdmin, async (req, res) => {
    try {
        const [forms] = await db.execute(`
            SELECT st.*, u.full_name as creator_name 
            FROM Survey_Templates st 
            LEFT JOIN Users u ON st.created_by = u.id 
            WHERE st.is_deleted = 0
            ORDER BY st.created_at DESC
        `);
        res.render('admin/forms', { forms });
    } catch (err) {
        res.status(500).send('Lỗi tải danh sách biểu mẫu');
    }
});

// 2. Giao diện tạo mới / sửa biểu mẫu
router.get('/forms/builder', isAdmin, async (req, res) => {
    const { id } = req.query;
    let form = null;
    if (id) {
        const [forms] = await db.execute('SELECT * FROM Survey_Templates WHERE id = ?', [id]);
        if (forms.length > 0) form = forms[0];
    }
    res.render('admin/form-builder', { form });
});

// 3. Xử lý Lưu biểu mẫu (Tạo mới hoặc Cập nhật)
router.post('/forms/save', isAdmin, async (req, res) => {
    const { id, title, description, form_structure } = req.body;
    try {
        if (id) {
            await db.execute(
                'UPDATE Survey_Templates SET title = ?, description = ?, form_structure = ? WHERE id = ?',
                [title, description, form_structure, id]
            );
            await logAction(req.session.userId, null, 'EDIT_FORM', `Sửa biểu mẫu: ${title}`);
        } else {
            await db.execute(
                'INSERT INTO Survey_Templates (title, description, form_structure, created_by) VALUES (?, ?, ?, ?)',
                [title, description, form_structure, req.session.userId]
            );
            await logAction(req.session.userId, null, 'ADD_FORM', `Tạo biểu mẫu mới: ${title}`);
        }
        res.redirect('/admin/forms');
    } catch (err) {
        res.status(500).send('Lỗi lưu biểu mẫu');
    }
});

// 4. Khóa / Mở khóa biểu mẫu
router.post('/forms/toggle/:id', isAdmin, async (req, res) => {
    try {
        await db.execute('UPDATE Survey_Templates SET is_active = NOT is_active WHERE id = ?', [req.params.id]);
        res.redirect('/admin/forms');
    } catch (err) {
        res.status(500).send('Lỗi cập nhật trạng thái biểu mẫu');
    }
});

// 5. Xóa mềm biểu mẫu
router.post('/forms/delete/:id', isAdmin, async (req, res) => {
    try {
        await db.execute('UPDATE Survey_Templates SET is_deleted = 1, is_active = 0 WHERE id = ?', [req.params.id]);
        res.redirect('/admin/forms');
    } catch (err) {
        res.status(500).send('Lỗi xóa biểu mẫu');
    }
});

module.exports = router;